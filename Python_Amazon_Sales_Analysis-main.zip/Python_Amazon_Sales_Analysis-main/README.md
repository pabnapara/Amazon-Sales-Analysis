# Python_Amazon_Sales_Analysis

Python project for beginners- Analyze Amazon sales data to check the buyers preferred choice in the sales
